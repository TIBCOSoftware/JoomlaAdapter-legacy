INSERT INTO `#__email_templates` (`subject`, `alias`, `content`, `language`, `created`, `created_by`, `last_modified`, `last_modified_by`, `published`, `isHTML`) VALUES ( 'Request Processed', 'request_plan_processed', 'Notification: A request to the ''{PLAN_NAME}'' plan has been processed. \n\nProduct: {PRODUCT_URL} \nRate limit: {RATE_LIMIT} \nQuota limit: {QUOTA_LIMIT}\nRequest status: {STATUS}\nCanceler:{CANCELER}\n', '', '2014-08-19 03:14:05', 129, '2014-08-19 08:33:40', 129, 1, 0);
DELETE FROM `#__modules` WHERE `id` = 104;
CREATE TABLE IF NOT EXISTS `#__request_list` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `created_by` int(10) NOT NULL,
  `requested_by` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `product` varchar(128) NOT NULL,
  `product_id` int(10) NOT NULL,
  `application_id` varchar(255) NOT NULL DEFAULT '0',
  `subscriptions_id` int(11) NOT NULL DEFAULT '0',
  `status` tinyint(3) NOT NULL,
  `updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `plan` varchar(128) NOT NULL,
  `plan_id` int(10) NOT NULL,
  `org_id` int(10) NOT NULL,
  `user_note` text NOT NULL,
  `admin_note` text NOT NULL,
  `custom` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `subscriptions_id` (`subscriptions_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;