<?php
class com_migrateInstallerScript{
	private $dbPath = '/administrator/components/com_migrate/db/';
	public $getInfo = '';
	public function install() {
		$this->updateTable ();
		$this->insertTable ();
		$this->fieldsJson ();
		$this->UpdateField();
		/**
		 * add fields' default value
		*/
		$this->addGateway ();
		$this->addNewEnvironmentFields ();
		$this->changeHtmlHeight ();
		$this->changeEnviromentOrdering ();
		$this->showInformation ();
	}
	public function update() {
		$this->updateTable ();
		$this->insertTable ();
		$this->fieldsJson ();
		$this->UpdateField();
		/**
		 * add fields' default value
		*/
		$this->addGateway ();
		$this->addNewEnvironmentFields ();
		$this->changeHtmlHeight ();
		$this->changeEnviromentOrdering ();
		$this->showInformation ();
	}
	/* Data that can directly insert,update,create and delete */
	private function insertTable() {
		$this->directInsert ( 'directUpdate.sql' );
		/* add component and connection menu */
		$db = JFactory::getDbo ();
		$extensionSql = "INSERT INTO `#__extensions` (`name`, `type`, `element`, `folder`, `client_id`, `enabled`, `access`, `protected`, `manifest_cache`, `params`, `custom_data`, `system_data`, `checked_out`, `checked_out_time`, `ordering`, `state`) VALUES ('com_request', 'component', 'com_request', '', 1, 1, 1, 0, '{\"name\":\"com_request\",\"type\":\"component\",\"creationDate\":\"2014-06-30\",\"author\":\"burtyu\",\"copyright\":\"\",\"authorEmail\":\"ybt7755221@sohu\.com\",\"authorUrl\":\"http:\\/\\/burtyu\.com\",\"version\":\"1\.0\.0\",\"description\":\"request list\",\"group\":\"\"}', '{}', '', '', 0, '0000-00-00 00:00:00', 0, 0)";
		$db->setQuery ( $extensionSql );
		$db->execute ();
		$component_id = $db->insertid ();
		/* check if have this menu */
		$subscriptionSql = 'SELECT `id`,`lft`,`rgt` FROM `#__menu` WHERE `title` = "Subscriptions" AND `parent_id` = 1';
		$db->setQuery($subscriptionSql);
		$sObj = $db->loadObject();
		$sRgt = $sObj->rgt;
		$sLft = $sObj->lft;
		$sId = $sObj->id;

		$lft = $sLft + 1;
		$rgt = $sLft + 2;
		$menu1Sql = "INSERT INTO `#__menu` (`menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES ('top', 'Subscriptions', 'subscriptions', '', 'subscriptions/subscriptions', 'index.php?option=com_cobalt&view=records&section_id=6:subscriptions', 'component', 1, 114, 2, 10001, 0, '0000-00-00 00:00:00', 0, 10, '', 0, '{\"menu_archive\":\"0\",\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', ".$lft.", ".$rgt.", 0, '*', 0)";
		$db->setQuery ( $menu1Sql );
		$db->execute ();

		$cSql = 'SELECT `id` FROM `#__menu` WHERE `client_id` = 0 AND `parent_id` = 1 AND `alias` = "requests" AND `language` = "*"';
		$db->setQuery ( $cSql );
		$isHave = $db->loadObject ();
		if (! $isHave->id) {
			$lft = $sLft + 3;
			$rgt = $sLft + 4;
			$menuSql = "INSERT INTO `#__menu` (`menutype`, `title`, `alias`, `note`, `path`, `link`, `type`, `published`, `parent_id`, `level`, `component_id`, `checked_out`, `checked_out_time`, `browserNav`, `access`, `img`, `template_style_id`, `params`, `lft`, `rgt`, `home`, `language`, `client_id`) VALUES ('top', 'Requests', 'requests', '', 'subscriptions/requests', 'index.php?option=com_request&view=lists', 'component', 1, 114, 2, " . $component_id . ", 0, '0000-00-00 00:00:00', 0, 10, '', 0, '{\"menu-anchor_title\":\"\",\"menu-anchor_css\":\"\",\"menu_image\":\"\",\"menu_text\":1,\"page_title\":\"\",\"show_page_heading\":0,\"page_heading\":\"\",\"pageclass_sfx\":\"\",\"menu-meta_description\":\"\",\"menu-meta_keywords\":\"\",\"robots\":\"\",\"secure\":0}', ".$lft.", ".$rgt.", 0, '*', 0)";
			$db->setQuery ( $menuSql );
			$db->execute ();
		}
		
		$top = 'SELECT `id`,`params` FROM `#__modules` WHERE `title` = "top"';
		$db->setQuery($top);
		$mObj = $db->loadObject();
		$moduleArr = json_decode($mObj->params, true);
		$moduleArr['showAllChildren'] = 1;
		$newObj = addslashes( json_encode($moduleArr) );
		$mUpdate = "UPDATE `#__modules` SET `params` = '".$newObj."' WHERE `id` = ".$mObj->id;
		$db->setQuery($mUpdate);
		$db->execute();
		
		if ($sLft < $rgt){
			$sRgt = $sLft + 5;
			$sUpdate = 'UPDATE `#__menu` SET `rgt` = '.$sRgt.' WHERE `id` = '.$sId;
			$db->setQuery( $sUpdate );
			$db->execute();
		}

		$this->directInsert ( 'directFieldsAssets.sql' );
	}
	private function fieldsJson() {
		$db = JFactory::getDbo ();
		$sql = 'SELECT `params` FROM `#__js_res_fields` WHERE `id` = 26';
		$db->setQuery ( $sql );
		$paramStr = $db->loadObject ();
		$paramArr = json_decode ( $paramStr->params, true );
		if ($paramArr ['params'] ['add_existing_access_full'] != 0) {
			$paramArr ['params'] ['add_existing_access_full'] = 0;
			$paramString = addslashes( json_encode ( $paramArr ) );
			$insertSql = 'UPDATE `#__js_res_fields` SET `params` = \'' . $paramString . '\' WHERE `id` = 26';
			$db->setQuery ( $insertSql );
			$db->execute ();
		}
		
		$sql = 'SELECT `params` FROM `#__js_res_fields` WHERE `id` = 28';
		$db->setQuery ( $sql );
		$paramStr = $db->loadObject ();
		$paramArr = json_decode ( $paramStr->params, true );
		if ($paramArr ['core'] ['required'] != 1) {
			$paramArr ['core'] ['required'] = 1;
			$paramString = addslashes( json_encode ( $paramArr ) );
			$insertSql = 'UPDATE `#__js_res_fields` SET `params` = \'' . $paramString . '\' WHERE `id` = 28';
			$db->setQuery ( $insertSql );
			$db->execute ();
		}
	
		$sql = 'SELECT `params` FROM `#__js_res_fields` WHERE `id` = 64';
		$db->setQuery ( $sql );
		$paramStr = $db->loadObject ();
		$paramArr = json_decode ( $paramStr->params, true );
		if ($paramArr ['params'] ['template_input'] != 'default_support_ie9.php') {
			$paramArr ['params'] ['template_input'] = 'default_support_ie9.php';
			$paramString = addslashes( json_encode ( $paramArr ) );
			$insertSql = 'UPDATE `#__js_res_fields` SET `params` = \'' . $paramString . '\' WHERE `id` = 64';
			$db->setQuery ( $insertSql );
			$db->execute ();
		}
	
		$sql = 'SELECT `params` FROM `#__js_res_fields` WHERE `id` = 87';
		$db->setQuery ( $sql );
		$paramStr = $db->loadObject ();
		$paramArr = json_decode ( $paramStr->params, true );
		if ($paramArr ['params'] ['multi_limit'] != '10000') {
			$paramArr ['params'] ['multi_limit'] = 10000;
			$paramString = addslashes( json_encode ( $paramArr ) );
			$insertSql = 'UPDATE `#__js_res_fields` SET `params` = \'' . $paramString . '\' WHERE `id` = 87';
			$db->setQuery ( $insertSql );
			$db->execute ();
		}
		$sql = 'SELECT `params` FROM `#__js_res_fields` WHERE `id` = 131';
		$db->setQuery ( $sql );
		$paramStr = $db->loadObject ();
		$paramArr = json_decode ( $paramStr->params, true );
		if ($paramArr ['core'] ['show_intro'] != 0) {
			$paramArr ['core'] ['show_intro'] = 0;
			$paramString = addslashes( json_encode ( $paramArr ) );
			$insertSql = 'UPDATE `#__js_res_fields` SET `params` = \'' . $paramString . '\' WHERE `id` = 131';
			$db->setQuery ( $insertSql );
			$db->execute ();
		}
		$this->updateTypes ();
	}
	
	/* Update types data */
	private function updateTypes() {
		$lang = JFactory::getLanguage();
		$lang->load('com_logs');
		$firstInfo = '';
		$db = JFactory::getDbo ();
		for($i = 1; $i < 13; $i ++) {
			$sql = 'SELECT `name`, `params` FROM `#__js_res_types` WHERE `id` = ' . $i;
			$db->setQuery ( $sql );
			$paramStr = $db->loadObject ();
			$paramArr = json_decode ( $paramStr->params, true );

				if ($paramArr ['audit'] ['versioning'] == 1) {
					$firstInfo .= JText::sprintf ( 'MIGRATION_TYPE', $paramStr->name ).'<br/>';
				}
				$paramArr ['audit'] ['versioning'] = 0;
				$paramArr ['audit'] ['al26'] = 0;
				if ($i == 1) {
					/* Add 'comments' in types id = 1 */
					if (! empty ( $paramArr ['comments'] ) || ! empty ( $paramArr ['comments'] ['comments'] )) {
						$endInfo = JText::sprintf ( 'MIGRATION_COMMENT', $paramStr->name ).'<br/>';
					}
					$paramArr ['comments'] = array (
							'comments' => 'core',
							'comment_captcha' => 1,
							'comments_nocomment' => 0,
							'comments_access_post' => 2,
							'comments_access_access' => 10,
							'comments_access_view' => 1,
							'comments_access_moderate' => 10,
							'comments_lang_mode' => 0,
							'comments_approve' => 0,
							'comments_approve_author' => 0,
							'comments_author_block' => 1,
							'comments_comment_author_edit' => 1,
							'comments_comment_author_delete' => 1,
							'comments_private' => 2,
							'comments_hide_access' => 10,
							'comments_hide_access_author' => 1,
							'comments_rate_rate' => 0,
							'comments_rate_view' => 0,
							'comments_rate_delete' => 100,
							'comment_attach' => 3,
							'comments_attachment_overwrite' => 1,
							'comments_attachment_hit' => 1,
							'comments_attachment_size' => 1,
							'comments_allowed_formats' => 'pdf, zip, doc, jpg, jpeg, png, gz, tar, docx, xls, xlsx, ppt, pptx',
							'comments_attachment_max' => '2097152',
							'comments_max_count' => 3
					);
				}
				if ($i == 7) {
					$paramArr ['submission'] ['first_category'] = 1;
				}
				$paramString = addslashes( json_encode ( $paramArr ) );
				$insertSql = 'UPDATE `#__js_res_types` SET `params` = \'' . $paramString . '\' WHERE `id` = ' . $i;
				$db->setQuery ( $insertSql );
				$db->execute ();
				$this->getInfo = $firstInfo . $endInfo;
			
		}
	}
	
	/* Update date to datebase (not include json`s change) */
	private function updateTable() {
		/* Get data that need update. */
		$checkVersion = $this->checkVersion();
		$Uform = $this->NeedChangeData($checVersion);
		$db = JFactory::getDbo();
		foreach ( $Uform as $key => $value ) {
			foreach ( $value ['fields'] as $k => $v ) {
				/* Check if old data is same as user data. */
				$sql = 'SELECT `' . $k . '` FROM `' . $value ['table'] . '` WHERE `id` = ' . $value ['id'];
				$db->setQuery ( $sql );
				$Obj = $db->loadObject ();
				$check = $Obj->$k;
				if ($check != $v ['new']) {
					$updateSql = 'UPDATE `' . $value ['table'] . '` SET `' . $k . '` = \'' . $v ['new'] . '\' WHERE `id` = ' . $value ['id'];
					$db->setQuery ( $updateSql );
					$res = $db->execute ();
					if ($check != $v ['old']) {
						$this->getInfo .= 'Your ' . $k . ' default value is ' . $check . '. Now we had been changed is ' . $v ['new'];
					}
				}
			}
		}
	}
	/* Data can directly update and need not modify */
	private function directInsert($file) {
		$sqlArr = $this->getSql ( $file );
		$db = JFactory::getDbo ();
		foreach ( $sqlArr as $val ) {
			$db->setQuery ( $val );
			$db->execute ();
		}
	}
	private function getSql($filename) {
		$path = JPATH_ROOT . $this->dbPath . $filename;
		$resArr = array ();
		$fh = fopen ( $path, 'r' );
		while ( ! feof ( $fh ) ) {
			$line = trim ( fgets ( $fh ) );
			if (! empty ( $line )) {
				$lineEnd = substr ( $line, - 1 );
				if ($lineEnd == ';') {
					if (empty ( $temp )) {
						$line = substr ( $line, 0, - 1 );
						$resArr [] = $line;
					} else {
						$temp .= $line;
						$temp = substr ( $temp, 0, - 1 );
						$resArr [] = $temp;
						$temp = '';
					}
				} else {
					$temp .= $line;
				}
			}
		}
		return $resArr;
	}
	private function addGateway() {
		$db = JFactory::getDbo ();
		$sql = 'SELECT `id`,`fields`, `user_id` FROM `#__js_res_record` WHERE `type_id` = 2';
		$db->setQuery ( $sql );
		$obj = $db->loadObjectList ();
		foreach ( $obj as $val ) {
			$selectSql = 'SELECT `id` FROM `#__js_res_record_values` WHERE `field_id` = 145 AND `record_id` = ' . $val->id;
			$db->setQuery ( $selectSql );
			$recordObj = $db->loadObject ();
			if (! isset ( $recordObj->id ) || empty ( $recordObj->id )) {
				$nowTime = date ( 'Y-m-d H:i:s', time () );
				$insertSql = 'INSERT INTO `#__js_res_record_values` (`field_id`, `field_key`, `field_type`, `field_label`, `field_value`, `record_id`, `user_id`, `type_id`, `section_id`, `category_id`, `params`, `ip`, `ctime`, `value_index` ) VALUES ( 145, "kbfb46d67444065b006967432fb1d11b3", "boolean", "Create Proxy for API", -1, ' . $val->id . ', ' . $val->user_id . ', 2, 2, 0, "", "127.0.0.1", "' . $nowTime . '", 0 )';
				$db->setQuery ( $insertSql );
				$db->execute ();
			}
			$obj = json_decode ( $val->fields, true );
			if (! isset ( $obj ['145'] )) {
				$obj [145] = - 1;
				$json = addslashes( json_encode ( $obj ) );
				$inSql = 'UPDATE `#__js_res_record` SET `fields` = "' . $json . '" WHERE `id` = ' . $val->id;
				$db->setQuery ( $inSql );
				$db->execute ();
			}
		}
		return true;
	}
	private function addNewEnvironmentFields() {
		$db = JFactory::getDbo ();
		$sql = 'SELECT `id`,`fields`, `user_id` FROM `#__js_res_record` WHERE `type_id` = 4';
		$db->setQuery ( $sql );
		$obj = $db->loadObjectList ();
		foreach ( $obj as $val ) {
			$selectSql = 'SELECT `id` FROM `#__js_res_record_values` WHERE `field_id` = 145 AND `record_id` = ' . $val->id;
			$db->setQuery ( $selectSql );
			$recordObj = $db->loadObject ();
			if (! isset ( $recordObj->id ) || empty ( $recordObj->id )) {
				$nowTime = date ( 'Y-m-d H:i:s', time () );
				$insertSql = 'INSERT INTO `#__js_res_record_values` (`field_id`, `field_key`, `field_type`, `field_label`, `field_value`, `record_id`, `user_id`, `type_id`, `section_id`, `category_id`, `params`, `ip`, `ctime`, `value_index` ) VALUES ( 132, "k2bbba040aea1ea47710820a38f288744", "boolean", "Managed by Gateway", 1, ' . $val->id . ', ' . $val->user_id . ', 4, 3, 0, "", "::1", "' . $nowTime . '", 0 )';
				$db->setQuery ( $insertSql );
				$db->execute ();
			}
			$obj = json_decode ( $val->fields, true );
			if (! isset ( $obj ['132'] )) {
				$obj [132] = 1;
				$json = addslashes( json_encode ( $obj ) );
				$inSql = 'UPDATE `#__js_res_record` SET `fields` = "' . $json . '" WHERE `id` = ' . $val->id;
				$db->setQuery ( $inSql );
				$db->execute ();
			}
		}
		return true;
	}
	private function changeHtmlHeight() {
		$db = JFactory::getDbo ();
		$sql = 'SELECT `extension_id`, `params` FROM `#__extensions` WHERE `name` = "plg_editors_tinymce" AND `type` = "plugin"';
		$db->setQuery ( $sql );
		$obj = $db->loadObject ();
		if (isset ( $obj->extension_id ) && ! empty ( $obj->extension_id )) {
			$arr = json_decode ( $obj->params, true );
			if (isset ( $arr ['html_height'] )) {
				$arr ['html_height'] = "300";
			}
			$json = addslashes( json_encode ( $arr ) );
			$inSql = 'UPDATE `#__extensions` SET `params` = \'' . $json . '\' WHERE `extension_id` = ' . $obj->extension_id;
			$db->setQuery ( $inSql );
			$db->execute ();
		}
		return true;
	}
	private function changeEnviromentOrdering() {
		$db = JFactory::getDbo ();
		$sql = 'SELECT `ordering` FROM `#__js_res_fields` WHERE `id` = 26';
		$db->setQuery ( $sql );
		$Obj = $db->loadObject ();
		$insertSql = 'UPDATE `#__js_res_fields` SET `ordering` =' . $Obj->ordering . ' WHERE `label` = "Target Environment" AND `type_id` = 2';
		$db->setQuery ( $insertSql );
		$db->execute ();
	}
	private function NeedChangeData( $ver ) {
		if ($ver == 1){
			$resArr =  array (
					array (
							'table' => '#__assets',
							'id' => 1,
							'fields' => array (
									'rgt' => array (
											'old' => 361,
											'new' => 375
									)
							)
					),
					array (
							'table' => '#__assets',
							'id' => 78,
							'fields' => array (
									'title' => array (
											'old' => 'Environments',
											'new' => 'Environment'
									)
							)
					),
					array (
							'table' => '#__js_res_fields',
							'id' => 22,
							'fields' => array (
									'published' => array (
											'old' => '1',
											'new' => '0'
									)
							)
					),
					array (
							'table' => '#__js_res_fields',
							'id' => 26,
							'fields' => array (
									'label' => array (
											'old' => 'Environments',
											'new' => 'Environment'
									),
									'key' => array (
											'old' => 'kf2bf86d86e26fa0a8502a27883167ce6',
											'new' => 'k5ec4b12cae674991fdc76badbe2e498b'
									)
							)
					),
					array (
							'table' => '#__menu',
							'id' => 114,
							'fields' => array (
									'link' => array (
											'old' => 'option=com_cobalt&view=records&section_id=6',
											'new' => 'option=com_cobalt&view=records&section_id=6:subscriptions'
									),
									'access' => array (
											'old' => 10,
											'new' => 8
									)
							)
					)
			);
		}elseif( $ver == 2 ){
			$resArr = array (
					array (
							'table' => '#__assets',
							'id' => 1,
							'fields' => array (
									'rgt' => array (
											'old' => 365,
											'new' => 411
									)
							)
					),
					array (
							'table' => '#__assets',
							'id' => 78,
							'fields' => array (
									'title' => array (
											'old' => 'Environments',
											'new' => 'Environment'
									)
							)
					),
					array (
							'table' => '#__js_res_fields',
							'id' => 22,
							'fields' => array (
									'published' => array (
											'old' => '1',
											'new' => '0'
									)
							)
					),
					array (
							'table' => '#__js_res_fields',
							'id' => 26,
							'fields' => array (
									'label' => array (
											'old' => 'Environments',
											'new' => 'Environment'
									),
									'key' => array (
											'old' => 'kf2bf86d86e26fa0a8502a27883167ce6',
											'new' => 'k5ec4b12cae674991fdc76badbe2e498b'
									)
							)
					),
					array (
							'table' => '#__menu',
							'id' => 114,
							'fields' => array (
									'link' => array (
											'old' => 'option=com_cobalt&view=records&section_id=6',
											'new' => 'option=com_cobalt&view=records&section_id=6:subscriptions'
									),
									'access' => array (
											'old' => 10,
											'new' => 8
									)
							)
					)
			);
		}else{
			$resArr =  array (
					array (
							'table' => '#__assets',
							'id' => 1,
							'fields' => array (
									'rgt' => array (
											'old' => 361,
											'new' => 375
									)
							)
					),
					array (
							'table' => '#__assets',
							'id' => 78,
							'fields' => array (
									'title' => array (
											'old' => 'Environments',
											'new' => 'Environment'
									)
							)
					),
					array (
							'table' => '#__js_res_fields',
							'id' => 22,
							'fields' => array (
									'published' => array (
											'old' => '1',
											'new' => '0'
									)
							)
					),
					array (
							'table' => '#__js_res_fields',
							'id' => 26,
							'fields' => array (
									'label' => array (
											'old' => 'Environments',
											'new' => 'Environment'
									),
									'key' => array (
											'old' => 'kf2bf86d86e26fa0a8502a27883167ce6',
											'new' => 'k5ec4b12cae674991fdc76badbe2e498b'
									)
							)
					),
					array (
							'table' => '#__menu',
							'id' => 114,
							'fields' => array (
									'link' => array (
											'old' => 'option=com_cobalt&view=records&section_id=6',
											'new' => 'option=com_cobalt&view=records&section_id=6:subscriptions'
									),
									'access' => array (
											'old' => 10,
											'new' => 8
									)
							)
					)
			);
		}
		return $resArr;
	}
	private function showInformation() {
		echo "<script>Joomla.renderMessages({info: ['" . $this->getInfo . "']});</script>";
		$this->insertLogs ( 0, 200, $this->getInfo );
	}
	private function getUuid($prefix = ''){
		$chars  =  md5(uniqid(mt_rand(), true));
		$uuid   =  substr ( $chars ,0,8).'-';
		$uuid  .=  substr ( $chars ,8,4).'-';
		$uuid  .=  substr ( $chars ,12,4).'-';
		$uuid  .=  substr ( $chars ,16,4).'-';
		$uuid  .=  substr ( $chars ,20,12);
		return $prefix.$uuid;
	}
	private function insertLogs($plan_id, $state, $content) {
		$user_id = 129;
		$org = $this->getOrganization ( $user_id );
		$user_org = $org [0];
		$uuid = $this->getUuid ( '' );
		$is_show = 0;
		$log_type = 'migrate';
		$http_status = 200;
		$content = htmlspecialchars ( '<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\"><html><head><title>200 Success</title></head><body><h1>Migration Information</h1><p>' . $content . '</p></body></html>' );
		$entity_type = 'Plan';
		$entity_id = $plan_id;
		$event = 'Migrate';
		$event_status = 'Migrate';
		$status = 1;
		$published = 1;
		$create_time = date ( 'Y-m-d H:i:s', time () );
		$db = JFactory::getDbo ();
		$sql = 'INSERT INTO asg_logs (`uuid`,`uid`,`org_id`,`is_show`,`log_type`,`http_status`,`summary`,`content`,`entity_type`,`entity_id`,`event`,`event_status`,`status`,`published`,`create_time`)';
		$sql .= 'VALUES ("' . $uuid . '", ' . $user_id . ', ' . $user_org . ', ' . $is_show . ', "' . $log_type . '", "' . $http_status . '", "' . $content . '", "' . $content . '", "' . $entity_type . '", ' . $entity_id . ', "' . $event . '", "' . $event_status . '", ' . $status . ', ' . $published . ', "' . $create_time . '")';
		$db->setQuery ( $sql );
		$db->execute ();
	}
	private function getOrganization($user_id) {
		$rv = array ();
		$db = JFactory::getDbo ();
		$db->setQuery ( "SELECT field_value FROM #__js_res_record_values WHERE record_id IN (SELECT record_id FROM #__js_res_record_values WHERE field_id=77 AND field_value=" . $user_id . ") and field_id=47" );
		if ($result = $db->loadObjectList ()) {
			foreach ( $result as $record ) {
				array_push ( $rv, $record->field_value );
			}
		}
		return $rv;
	}
	private function UpdateField(){
    	$db = JFactory::getDbo();
    	$sql = 'SELECT `params` FROM `#__js_res_fields` WHERE `id` = 135';
    	$db->setQuery($sql);
    	$paramsObj = $db->loadObject();
    	$paramArr = json_decode ( $paramsObj->params, true );
    	$paramArr['params'] = array(
			"template_input" => "default_password.php",
			"template_output_list" => "default.php",
			"template_output_full" => "default_password_record.php",
			"sortable" => "0",
			"ordering_mode" => "digits",
			"template_filter" => "autocomplete.php",
			"template_filter_module" => "autocomplete.php",
			"filter_enable" => "0",
			"filter_hide" => "0",
			"filter_descr" => "",
			"filter_show_number" => "1",
			"filter_linkage" => "1",
			"filter_icon" => "funnel-small.png",
			"filter_tip" => "Show all records where %s is equal to %s",
			"maxlength" => "0",
			"default_val" => "0",
			"size" => "90%",
			"prepend" => "",
			"append" => "",
			"allow_html" => "0",
			"is_unique" => "0",
			"length" => "0",
			"seemore" => ">>>",
			"qr_code" => "0",
			"qr_width" => "60",
			"regex_val" => "",
			"mask" => array(
			        "mask_type" => "",
			        "mask" => "",
			),
			"show_mask" => "1",
		);
		$Obj = addslashes( json_encode($paramArr) );
    	$sql1 = 'UPDATE `#__js_res_fields` SET `key` = "k81f1fc559deaa1605220c2d178d91d1c" WHERE `id` = 135';
    	$sql2 = 'UPDATE `#__js_res_fields` SET `field_type` = "text" WHERE `id` = 135';
    	$sql3 = "UPDATE `#__js_res_fields` SET `params` = '".$Obj."' WHERE `id` = 135";
    	$db->setQuery($sql1);
    	$db->execute();
    	$db->setQuery($sql2);
    	$db->execute();
    	$db->setQuery($sql3);
    	$db->execute();
    }
	private function checkVersion(){
		$db = JFactory::getDbo ();
		$sql = 'SELECT `id` FROM `#__template_styles` WHERE `template` = "nielsen" AND `client_id` = 0 AND `home` = 1';
		$db->setQuery($sql);
		$version = $db->loadObject();
		if ( isset($version->id) && !empty($version->id) )
			$res = 2;
		else 
			$res = 1;
		return $res;
	}
}

