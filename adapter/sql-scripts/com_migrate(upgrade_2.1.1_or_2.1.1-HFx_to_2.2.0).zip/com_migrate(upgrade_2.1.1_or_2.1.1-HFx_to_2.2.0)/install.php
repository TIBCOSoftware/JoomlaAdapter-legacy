<?php
class com_migrateInstallerScript{
	private $dbPath = '/administrator/components/com_migrate/db/';
	public $getInfo = '';
	public function install() {
		if ( $this->checkFields() )
			$this->directInsert( 'directUpdate_211.sql' );
		else
			$this->directInsert( 'directUpdate_hf1.sql' );
		$this->modifyRecord();
    $this->modifyPlan();
	}
	public function update() {
		if ( $this->checkFields() )
			$this->directInsert( 'directUpdate_211.sql' );
		else
			$this->directInsert( 'directUpdate_hf1.sql' );
		$this->modifyRecord();
    $this->modifyPlan();
	}
	
	/**
	 * Data can directly update and need not modify 
	*/
	private function directInsert($file) {
		$sqlArr = $this->getSql ( $file );
		$db = JFactory::getDbo ();
		foreach ( $sqlArr as $val ) {
			$db->setQuery ( $val );
			$db->execute ();
		}
	}
	/**
	 * Get sql script from db directory.
	*/
	private function getSql($filename) {
		$path = JPATH_ROOT . $this->dbPath . $filename;
		$resArr = array ();
		$fh = fopen ( $path, 'r' );
    $temp = '';
		while ( ! feof ( $fh ) ) {
			$line = trim ( fgets ( $fh ) );
			if (! empty ( $line )) {
				$lineEnd = substr ( $line, - 1 );
				if ($lineEnd == ';') {
					if (empty ( $temp )) {
						$line = substr ( $line, 0, - 1 );
						$resArr [] = $line;
					} else {
						$temp .= $line;
						$temp = substr ( $temp, 0, - 1 );
						$resArr [] = $temp;
						$temp = '';
					}
				} else {
					$temp .= $line;
				}
			}
		}
		return $resArr;
	}

	private function checkFields() {
		$apps = JFactory::getConfig();
        $dbtable = $apps->get('db');
        $db = JFactory::getDbo();
        $sql = "SELECT `DATA_TYPE` FROM `information_schema`.`COLUMNS` where `TABLE_NAME`='asg_logs' and `COLUMN_NAME` = 'content' and `TABLE_SCHEMA` = '".$dbtable."' LIMIT 1 ";
        $db->setQuery($sql);
        $demo = $db->loadObject();
        if ($demo->DATA_TYPE == 'text'){
            return true;
        } else {
            return false;
        }
	}
	/**
	* Modified error information in the 'js_res_record' table.
	*/
	private function modifyRecord() {
    $db = JFactory::getDbo ();
    $sql = 'SELECT `id`, `access`, `user_id` FROM `#__js_res_record` where `section_id` = 5 ORDER BY `id` DESC';
    $db->setQuery( $sql );
    $applicationArray = $db->loadObjectList();
    if ( !empty($applicationArray) ){
      foreach ( $applicationArray as $value ) {
        $sql2 = 'SELECT `id` FROM `#__users` WHERE `id` = '.$value->user_id;
        $db->setQuery( $sql2 );
        $check = $db->loadObject();
        if ( !empty($check->id) ) {
          $access_id = $this->getUserAccessGroupId( $value->user_id );
          if ( $access_id != $value->access ) {
            $this->modifyAccess( $value->id, $access_id );
          }
        }
      }
    }   
  }

	private function modifyAccess( $id, $access_id ) {
		$db = JFactory::getDbo ();
		$sql = 'UPDATE `#__js_res_record` SET `access` = '. $access_id .' WHERE `id` = '.$id;
		$db->setQuery( $sql );
		$db->execute();
	}
	
    private function getUserAccessGroupId($id)
    {
        $org_groups = $this->getUserOrganizationGroupsIds($id);
        $user_group = $this->getUserOrganizationGroupIdByOrganizationsGroupIds($id, $org_groups);
        $acccess_name = $this->getUserOrganizationAccessLevelNameById($user_group);
        $acccess_id = $this->getUserOrganizationAccessIdByName($acccess_name);
        return $acccess_id;
    }
    /**Start for getUserAccessGroupId */
    private function getUserOrganization($id) {
        $rv = array();
        $db = JFactory::getDbo();
        $db -> setQuery("SELECT field_value FROM `#__js_res_record_values` WHERE `record_id` IN (SELECT `record_id` FROM `#__js_res_record_values` WHERE `field_id` = 77 AND `field_value` = " . $id . ") and `field_id` = 47");
        if ($result = $db -> loadObjectList()) {
            foreach ($result as $record) {
                array_push($rv, $record -> field_value);
            }
        }
        return $rv;
    }
    private function getUserOrganizationGroupsIds($id)
    {
        $orgs = $this->getUserOrganization($id);
        $result = array();
        if(!empty($orgs))
        {
            foreach ($orgs as $org){
                if($member_group = $this->getOrganizationIdByName('Organization '.$org.' Member')){
                    $result[] = $member_group;
                }
                if($contact_group = $this->getOrganizationIdByName('Organization '.$org.' Contact')){
                    $result[] = $contact_group;
                }
                if($manage_group = $this->getOrganizationIdByName('Organization '.$org.' Manager')){
                    $result[] = $manage_group;
                }
            }
        }
        return $result;
    }
    
    private function getUserOrganizationAccessLevelNameById($org_group_id = 0)
    {
       $result = '';
       if($org_group_id)
       {
         $db = JFactory::getDbo();
         $query = $db->getQuery(true);

         $query->select("title")->from("#__usergroups")->where('id="'.$org_group_id.'"');

         $db->setQuery($query);
         $result = $db->loadColumn();
         if(count($result))
         {
           $result = $result[0];
         }else{
           $result = '';
         }
       }
       return $result;
    }
    private function getUserOrganizationGroupIdByOrganizationsGroupIds($id, $org_groups = array())
    {
        $user = JFactory::getUser($id);
        $result = 0;
        if(!empty($org_groups))
        {
            foreach ($org_groups as $org_group_id) {
               if(in_array($org_group_id, $user->getAuthorisedGroups()))
               {
                $result = $org_group_id;
                break;
               }
            }
        }

        return $result;
    }
    private function getUserOrganizationAccessIdByName($access_name='')
    {
       $result = 0;
       if($access_name)
       {
         $db = JFactory::getDbo();
         $query = $db->getQuery(true);

         $query->select("id")->from("#__viewlevels")->where('title="'.$access_name.'"');

         $db->setQuery($query);
         $result = $db->loadColumn();
         if(count($result))
         {
           $result = $result[0];
         }else{
           $result = 0;
         }
       }
       return $result;
    }
    private function getOrganizationIdByName ($org_name = ''){
      $result = 0;
      if($org_name)
      {
        $db = JFactory::getDbo();
        $query = $db->getQuery(true);

        $query->select("id")->from("#__usergroups")->where('title="'.$org_name.'"');

        $db->setQuery($query);
        $result = $db->loadColumn();
        if(count($result))
        {
          $result = $result[0];
        }else{
            $result = 0;
        }
      }
      return $result;
    }
    /**End for getUserAccessGroupId*/
    /**Modified Plan*/
    public function modifyPlan(){
        $planArr = $this->getRecordIds(1,7);
        $db = JFactory::getDbo();
        if ($planArr) {
            foreach ($planArr as $value) {
                $tmp = json_decode($value->fields, true);
                $check79 = stripos($tmp[79],'/1');
                $check80 = stripos($tmp[80],'/1');
                if ( !$check79 )
                    $tmp[79] = $tmp[79].'/1 second';
                if ( !$check80 )
                    $tmp[80] = $tmp[80].'/1 day';
                $field = json_encode($tmp);
                $query = 'UPDATE `#__js_res_record` SET `fields` = \''.$field.'\' WHERE `id` = '.$value->id;
                $db->setQuery($query);
                $result = $db->execute();
                if ( $result ){
                    if ( !$check79 )
                        $this->modifyRecordValue($tmp[79], 79, $value->id);
                    if ( !$check80 )
                        $this->modifyRecordValue($tmp[80], 80, $value->id);
                }
            }
        }
    }

    private function getRecordIds($section_id, $type_id){
        $db = JFactory::getDbo();
        $query = 'SELECT `id`, `fields` FROM `#__js_res_record` WHERE `section_id` = '.$section_id.' AND `type_id` = '.$type_id;
        $db->setQuery($query);
        return $db->loadObjectList();
    }

    private function modifyRecordValue($field_value, $field_id,$record_id){
        $db = JFactory::getDbo();
        $query = 'UPDATE `#__js_res_record_values` SET `field_value` = "'.$field_value.'" WHERE `field_id` = '.$field_id.' AND `record_id` = '.$record_id;
        $db->setQuery($query);
        $db->loadObjectList();
    }
    /***/

}

