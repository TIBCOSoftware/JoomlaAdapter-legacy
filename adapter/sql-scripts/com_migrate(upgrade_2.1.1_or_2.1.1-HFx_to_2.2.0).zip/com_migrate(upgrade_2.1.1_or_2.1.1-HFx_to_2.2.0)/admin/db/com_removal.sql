DELETE FROM `#__assets` WHERE id in (302,303,304,305,306,307,308,309,310,312,314,316,317,318,319,321,323,324,325,326,327,328,329,330);
DELETE FROM `#__assets` WHERE id between 330 and 347;
DELETE FROM `#__js_res_fields` WHERE id in (220,208,151);
DELETE FROM `#__js_res_fields` WHERE id between 222 and 236;
DELETE FROM `#__js_res_fields` WHERE id between 200 and 207;
DELETE FROM `#__js_res_fields` WHERE id between 210 and 213;
DELETE FROM `#__js_res_sections` WHERE id in (20,21);
DELETE FROM `#__js_res_types` WHERE id in (20,21);
DELETE FROM `#__menu` WHERE id in (201,202,203);