<?php

class com_migrateInstallerScript{
        private $dbPath = '/administrator/components/com_migrate/db/';
        public $getInfo = '';
        public function install() {
            $this->updateTabels();
            $this->updateJson();
            $this->showInformation();
        }
        public function update()
	    {
            $this->updateTabels();
            $this->updateJson();
            $this->showInformation();
	    }
	    
	    private function changeMenu(){
	    	$db = JFactory::getDbo();
	    }
	    
	    private function updateJson(){
	    	$lang = JFactory::getLanguage();
	    	$lang->load('com_logs');
	    	$db = JFactory::getDbo();
	    	$sql = 'SELECT `extension_id`, `params` FROM `#__extensions` WHERE `name` = "com_emails"';
	    	$db->setQuery($sql);
	    	$Obj = $db->loadObject();
	    	if ( $Obj->extension_id ) {
	    		$paramArr = json_decode($Obj->params,true);
		    	$paramArr['enable_archiving_objects'] = "0";
		    	$paramArr['showPermissions'] = "0";
		    	$paramArr['showTextFilters'] = "0";
		    	$paramString = json_encode($paramArr);
				$insertSql = 'UPDATE `#__extensions` SET `params` = \''.$paramString.'\' WHERE `extension_id` = '.$Obj->extension_id;
				$db->setQuery($insertSql);
				$db->execute();
	    	}
	    	$idArr = array(19,102);
	    	foreach ( $idArr as $val ){
	    		$sql = 'SELECT `type_id`,`params` FROM `#__js_res_fields` WHERE `id` = '.$val;
	    		$db->setQuery($sql);
	    		$Obj = $db->loadObject();
	    		$paramArr = json_decode($Obj->params,true);
	    		if ( $paramArr['params']['send_mail'] != 0 ) {
	    			if ( $paramArr['params']['send_mail'] != 8 ) {
	    				$this->getInfo .= JText::sprintf('MIGRATION_EMAIL',$type->name).'<br/>';
	    			}
	    			$paramArr['params']['send_mail'] = 0;
	    			$paramString = json_encode($paramArr);
	    			$insertSql = 'UPDATE `#__js_res_fields` SET `params` = \''.$paramString.'\' WHERE `id` = '.$val;
	    			$db->setQuery($insertSql);
	    			$db->execute();
	    			$sSql = 'SELECT `name` FROM `#__js_res_types` WHERE `id` ='. $Obj->type_id;
	    			$db->setQuery($sSql);
	    			$type = $db->loadObject();
	    		}
	    	}
            $tSql = 'SELECT `template` FROM `#__template_styles` WHERE `client_id` = 1 AND `home` = 1';
            $db->setQuery($tSql);
            $template = $db->loadObject();
            $oldTemplate = $template->template;

	    	$sql = 'UPDATE `#__template_styles` SET `home` = 0 WHERE `client_id` = 1 AND `template` != "apixadmin"';
	    	$db->setQuery($sql);
	    	$db->execute();
            if ( $oldTemplate != 'isis' )
	    	  $this->getInfo .= JText::sprintf('MIGRATION_TEMPLATE',$oldTemplate);
	    }
    	
        private function updateTabels() {
        	$ver = $this->checkVersion();
        	if ( $ver == 2 ) {
            	$sqlArr = $this->getFile( 'UpdateForNielsen.sql', 'Sql' );
        	} else {
        		$sqlArr = $this->getFile( 'UpdateForHF.sql', 'Sql' );
        	}
            $db = JFactory::getDbo();
            foreach ( $sqlArr as $val ) {
                $db->setQuery($val);
                @$db->execute();
            }
        }
        
        
       
        private function getFile( $filename,$type = 'Json' ) {
            $path = JPATH_ROOT . $this->dbPath . $filename;
            if ( $type == 'Sql' ) {
                $resArr = array();
                $fh = fopen( $path, 'r' );
                while ( !feof($fh) ) {
                   $line = trim(fgets($fh));
                    if ( !empty($line) ) {
                        $lineEnd = substr($line,-1);
                        if ( $lineEnd == ';' ) {
                            if ( empty( $temp ) ) {
                                $line = substr($line,0, -1);
                                $resArr[] = $line;
                            } else {
                                $temp .= $line;
                                $temp = substr($temp,0, -1);
                                $resArr[] = $temp;
                                $temp = '';
                            }
                            
                        } else {
                            $temp .= $line;
                        }
                    }
                }
                $result = $resArr;
            }else if ( $type == 'Json' ) {
                $file = file_get_contents( $path );
                $result = json_decode($file, true);
            }
            return $result;        
        }
        private function showInformation() {
            if ( !empty($this->getInfo) ) {
            	echo "<script>Joomla.renderMessages({info: ['" . $this->getInfo . "']});</script>";
            	$this->insertLogs ( 0, 200, $this->getInfo );
            }
        }
        private function getUuid($prefix = ''){
        	$chars  =  md5(uniqid(mt_rand(), true));
        	$uuid   =  substr ( $chars ,0,8).'-';
        	$uuid  .=  substr ( $chars ,8,4).'-';
        	$uuid  .=  substr ( $chars ,12,4).'-';
        	$uuid  .=  substr ( $chars ,16,4).'-';
        	$uuid  .=  substr ( $chars ,20,12);
        	return $prefix.$uuid;
        }
        private function insertLogs($plan_id, $state, $content) {
        	$user_id = 129;
        	$org = $this->getOrganization ( $user_id );
        	$user_org = $org [0];
        	$uuid = $this->getUuid ( '' );
        	$is_show = 0;
        	$log_type = 'migrate';
        	$http_status = 200;
        	$content = htmlspecialchars ( '<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\"><html><head><title>200 Success</title></head><body><h1>Migration Information</h1><p>' . $content . '</p></body></html>' );
        	$entity_type = 'Plan';
        	$entity_id = $plan_id;
        	$event = 'Migrate';
        	$event_status = 'Migrate';
        	$status = 1;
        	$published = 1;
        	$create_time = date ( 'Y-m-d H:i:s', time () );
        	$db = JFactory::getDbo ();
        	$sql = 'INSERT INTO asg_logs (`uuid`,`uid`,`org_id`,`is_show`,`log_type`,`http_status`,`summary`,`content`,`entity_type`,`entity_id`,`event`,`event_status`,`status`,`published`,`create_time`)';
        	$sql .= 'VALUES ("' . $uuid . '", ' . $user_id . ', ' . $user_org . ', ' . $is_show . ', "' . $log_type . '", "' . $http_status . '", "' . $content . '", "' . $content . '", "' . $entity_type . '", ' . $entity_id . ', "' . $event . '", "' . $event_status . '", ' . $status . ', ' . $published . ', "' . $create_time . '")';
        	$db->setQuery ( $sql );
        	$db->execute ();
        }
        private function getOrganization($user_id) {
        	$rv = array ();
        	$db = JFactory::getDbo ();
        	$db->setQuery ( "SELECT field_value FROM #__js_res_record_values WHERE record_id IN (SELECT record_id FROM #__js_res_record_values WHERE field_id=77 AND field_value=" . $user_id . ") and field_id=47" );
        	if ($result = $db->loadObjectList ()) {
        		foreach ( $result as $record ) {
        			array_push ( $rv, $record->field_value );
        		}
        	}
        	return $rv;
        }
        private function checkVersion(){
        	$db = JFactory::getDbo ();
        	$sql = 'SELECT `id` FROM `#__template_styles` WHERE `template` = "nielsen" AND `client_id` = 0 AND `home` = 1';
        	$db->setQuery($sql);
        	$version = $db->loadObject();
        	if ( isset($version->id) && !empty($version->id) )
        		$res = 2;
        	else
        		$res = 1;
        	return $res;
        }
}

