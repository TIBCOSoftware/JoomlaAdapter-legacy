<?php
class com_migrateInstallerScript{
	private $dbPath = '/administrator/components/com_migrate/db/';
	public $getInfo = '';
	public function install() {
		$this->directInsert( 'directUpdate.sql' );
	}
	public function update() {
		$this->directInsert( 'directUpdate.sql' );
	}
	
	/**
	 * Data can directly update and need not modify 
	*/
	private function directInsert($file) {
		$sqlArr = $this->getSql ( $file );
		$db = JFactory::getDbo ();
		foreach ( $sqlArr as $val ) {
			$db->setQuery ( $val );
			$db->execute ();
		}
	}
	/**
	 * Get sql script from db directory.
	*/
	private function getSql($filename) {
		$path = JPATH_ROOT . $this->dbPath . $filename;
		$resArr = array ();
		$fh = fopen ( $path, 'r' );
		while ( ! feof ( $fh ) ) {
			$line = trim ( fgets ( $fh ) );
			if (! empty ( $line )) {
				$lineEnd = substr ( $line, - 1 );
				if ($lineEnd == ';') {
					if (empty ( $temp )) {
						$line = substr ( $line, 0, - 1 );
						$resArr [] = $line;
					} else {
						$temp .= $line;
						$temp = substr ( $temp, 0, - 1 );
						$resArr [] = $temp;
						$temp = '';
					}
				} else {
					$temp .= $line;
				}
			}
		}
		return $resArr;
	}

}

