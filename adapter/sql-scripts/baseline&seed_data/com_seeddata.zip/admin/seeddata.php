<?php
// no direct access
defined('_JEXEC') or die;

// Include dependancies
jimport('joomla.application.component.controller');

$controller     = JControllerLegacy::getInstance('Seeddata');
$controller->execute(JFactory::getApplication()->input->get('task'));
$controller->redirect();