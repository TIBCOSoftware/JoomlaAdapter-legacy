<?php

class com_baselineInstallerScript{
        private $dbPath = '/administrator/components/com_baseline/db/';
        public function install() {
            $this->updateTabels();
            $this->changeHtmlHeight();
        }
        public function update()
	    {
            $this->updateTabels();
            $this->changeHtmlHeight();
            //return TRUE;
	    }
    
        private function getAllFiles() {
            $path = JPATH_ROOT . $this->dbPath;
            $fileArr = array();
            if ( $dh = opendir($path) ) {
                $n = 0;
                while ( ($file = readdir($dh)) !== false ) {
                    if ( $file != '.' && $file != '..' ) {
                        $fileArr[$n]['fileName'] = $file;
                        $fileArr[$n]['fileType'] = substr( $file, strripos( $file, '.' )+1 );
                        $n++; 
                    }
                }
                unset($fileTemp);
                closedir($dh);
            }
            return $fileArr;
        }
        
        private function updateTabels(){
            $needUpdate = $this->getAllFiles();
            foreach ( $needUpdate as $val ) {
                if ( $val['fileType'] == 'json' ) {
                   // $this->updateConstruct( $val['fileName'] );
                } elseif ( $val['fileType'] == 'sql' ) {
                    $this->updateData( $val['fileName'] );
                }
            }
        }
        
        private function updateData($file) {
            $sqlArr = $this->getFile( $file, 'Sql' );
            $db = JFactory::getDbo();
            foreach ( $sqlArr as $val ) {
                $db->setQuery($val);
                @$db->execute();
            }
        }
        
        private function updateConstruct( $filename ) {
            $table = substr( $filename, 0, stripos( $filename, '.') );
            $addArr = array();
            $db = JFactory::getDbo();
            $sql = "DESCRIBE `{$table}`";
            $db->setQuery($sql);
            $oldArr = $db->loadObjectList('Field');
            if ( !empty($oldArr) ) {
                    $newArr = $this->getFile($filename);
                    foreach ( $newArr as $val ) {
                        if ( array_key_exists($val->Field, $oldArr) ) {
                            if ( $val->Type != $oldArr[$val->Field]->Type || $val->Key != $oldArr[$val->Field]->Key || $val->Null != $oldArr[$val->Field]->Null || $val->Default != $oldArr[$val->Field]->Default ) {
                                $addArr['change'][$val->Field] = $val;
                                $addArr['change'][$val->Field]->OldKey = $oldArr[$val->Field]->Key;
                                if ( $val->Key == $oldArr[$val->Field]->Key ){
                                    unset($addArr['change'][$val->Field]->Key);
                                    unset($addArr['change'][$val->Field]->OldKey);
                                }
                            }
                            unset($oldArr[$val->Field]);
                        } else {
                            $addArr['add'][$val->Field]['Field'] = $val->Field;
                            $addArr['add'][$val->Field]['Type'] = $val->Type;
                            $addArr['add'][$val->Field]['Null'] = $val->Null;
                            $addArr['add'][$val->Field]['Key'] = $val->Key;
                            $addArr['add'][$val->Field]['Default'] = $val->Default;
                            $addArr['add'][$val->Field]['Extra'] = $val->Extra;
                        }
                    }
                    if ( !empty($oldArr) ) {
                        $addArr['del'] = array_keys($oldArr);
                    }
                    if( isset( $addArr ) && !empty( $addArr ) )
                    {
                        if ( !empty( $addArr['add'] ) )
                            $this->addField ($table, $addArr['add']);
                        if ( !empty( $addArr['change'] ) )
                            $this->changeField ($table, $addArr['change']);
                        if ( !empty( $addArr['del'] ) )
                            $this->delField ($table, $addArr['del']);
                    }
            }
        }
        
        private function addField( $table, $fieldArr ) {
            foreach ( $fieldArr as $val ) {
               $db = JFactory::getDbo();
               if ( !empty( $val['Default'] ) )
               {
                   $default = "DEFAULT '{$val['Default']}'";
               }
               if ( $val['Null'] == 'NO' )
               {
                   $null = "NOT NULL";
               }
               if ( !empty( $val['Key'] ) )
               {
                   switch ( $val['Key'] ) {
                        case 'PRI' :
                                    $key = ', ADD PRIMARY KEY(`'.$val["Field"].'`) '; 
                                    break;
                        case 'MUL' :
                                    $key = ', ADD INDEX(`'.$val["Field"].'`) ';   
                                    break;
                        case 'UNI' :
                                    $key = ', ADD UNIQUE(`'.$val["Field"].'`) ';   
                                    break;
                   }
                   
               }
               $sql = "ALTER TABLE `{$table}` ADD `{$val['Field']}` {$val['Type']} {$null} {$default} {$key}";
               $db->setQuery($sql);
               $db->execute();
            }
        }
        
        private function changeField( $table, $fieldArr ) {
            foreach ( $fieldArr as $val ) {
                if ( strtoupper($val->Null) == 'NO' )
                    $null = 'NOT NULL';
                else
                    $null = 'NULL';
                if ( $val->Default == NULL )
                    $default = '';
                else {
                    $default = "DEFAULT {$val->Default}";
                }
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` CHANGE `{$val->Field}` `{$val->Field}`{$val->Type} {$null} {$default}";
                $db->setQuery($sql);
                @$db->execute();
                if ( isset( $val->Key ) )
                    $this->changeKey($table, $val->Key, $val->Field, $val->OldKey);
            }
        }
        private function changeKey( $table, $key, $field, $oldKey ){
            if ( empty($key) ){
                $db = JFactory::getDbo();
                $sql = "drop index {$field} on {$table}";
                $db->setQuery($sql);
                @$db->execute();
            }elseif ( empty($oldKey) ) {
                switch ( $key ) {
                    case 'PRI' :
                                $keyText = 'PRIMARY KEY(`'.$field.'`) '; 
                                break;
                    case 'MUL' :
                                $keyText = 'INDEX(`'.$field.'`) ';   
                                break;
                    case 'UNI' :
                                $keyText = 'UNIQUE(`'.$field.'`) ';   
                                break;
                }
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` ADD {$keyText}";
                $db->setQuery($sql);
                @$db->execute();
            } else {
                switch ( $key ) {
                    case 'PRI' :
                                $keyText = 'PRIMARY KEY(`'.$field.'`) '; 
                                break;
                    case 'MUL' :
                                $keyText = 'INDEX(`'.$field.'`) ';   
                                break;
                    case 'UNI' :
                                $keyText = 'UNIQUE(`'.$field.'`) ';   
                                break;
                }
                $db = JFactory::getDbo();
                $sql = "drop index {$field} on {$table}";
                $db->setQuery($sql);
                @$db->execute();
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` ADD {$keyText}";
                $db->setQuery($sql);
                @$db->execute();
            }
        }
       
        private function delField( $table, $fieldArr ) {
            foreach ( $fieldArr as $val ) {
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` DROP `{$val}`";
                $db->setQuery($sql);
                $db->execute();
            }
            
        }
        private function getFile( $filename,$type = 'Json' ) {
            $path = JPATH_ROOT . $this->dbPath . $filename;
            if ( $type == 'Sql' ) {
                $resArr = array();
                $fh = fopen( $path, 'r' );
                while ( !feof($fh) ) {
                   $line = trim(fgets($fh));
                    if ( !empty($line) ) {
                        $lineEnd = substr($line,-1);
                        if ( $lineEnd == ';' ) {
                            if ( empty( $temp ) ) {
                                $line = substr($line,0, -1);
                                $resArr[] = $line;
                            } else {
                                $temp .= $line;
                                $temp = substr($temp,0, -1);
                                $resArr[] = $temp;
                                $temp = '';
                            }
                            
                        } else {
                            $temp .= $line;
                        }
                    }
                }
                $result = $resArr;
            }else if ( $type == 'Json' ) {
                $file = file_get_contents( $path );
                $result = json_decode($file);
            }
            return $result;        
        }
        private function changeHtmlHeight(){
            $db = JFactory::getDbo();
            $sql = 'SELECT `extension_id`, `params` FROM `#__extensions` WHERE `name` = "plg_editors_tinymce" AND `type` = "plugin"';
            $db->setQuery($sql);
            $obj = $db->loadObject();
            if ( isset($obj->extension_id) && !empty($obj->extension_id) ) {
                $arr = json_decode($obj->params,true);
                if ( isset($arr['html_height']) ) {
                    $arr['html_height'] = "300";
                }
                $json = addslashes(json_encode($arr));
                $inSql = 'UPDATE `#__extensions` SET `params` = \''.$json.'\' WHERE `extension_id` = '.$obj->extension_id;
                $db->setQuery($inSql);
                $db->execute();
            }
            return true;
        }
}

