<?php
/**
 * @package     TIBCO OpenApi
 * @subpackage  com_openapi
 * @copyright   Copyright 2013 TIBCO Software, Inc. All rights reserved.
 */

// No direct access
defined('_JEXEC') or die;

/**
 * Installation and Configuration for OpenAPI
 * 
 * @package		TIBCO OpenAPI
 * @subpackage	com_openapi
 * @since		1.0
 * @version		1.0
 *
 */
class OpenapiInstallerScript
{
	public function install($parent=null)
	{
		parent::install($parent);
		return true;
	}
	public function uninstall($parent=null)
	{
		parent::uninstall($parent);
		return true;
	}
	public function update($parent=null)
	{
		parent::update($parent);
		return true;
	}
}