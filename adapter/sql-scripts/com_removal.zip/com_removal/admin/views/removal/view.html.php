<?php

// No direct access
defined('_JEXEC') or die;

jimport('joomla.application.component.view');

class removalViewremoval extends JViewLegacy {
   
    
    public function display($tpl = null) {
        
        $this->allDB = $this->allDB();
        
        parent::display($tpl);
    }
    /**
     * Get all table in the database.
     */
    private function allDB() {
        $db = JFactory::getDbo();
        $sql = 'SHOW TABLES';
        $db->setQuery($sql);
        return $db->loadColumn();
    }
}

