DELETE FROM `#__assets` WHERE id in (302,303,304,305,306,307,308,309,310,312,314,316,317,318,319,321,323,324,325,326,327,328,329,330);
DELETE FROM `#__assets` WHERE id between 330 and 347;
DELETE FROM `#__js_res_fields` WHERE id in (220,208,151,152);
DELETE FROM `#__js_res_fields` WHERE id between 222 and 236;
DELETE FROM `#__js_res_fields` WHERE id between 200 and 207;
DELETE FROM `#__js_res_fields` WHERE id between 210 and 213;
DELETE FROM `#__js_res_sections` WHERE id in (20,21);
DELETE FROM `#__js_res_types` WHERE id in (20,21);
DELETE FROM `#__menu` WHERE id in (201,202,203);


INSERT INTO `#__assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES (332, 1, 431, 432, 1, 'com_cobalt.field.152', 'Concurrent Limit', '');

INSERT INTO `#__js_res_fields` (`id`, `key`, `label`, `type_id`, `field_type`, `params`, `checked_out`, `checked_out_time`, `published`, `ordering`, `access`, `group_id`, `asset_id`, `filter`, `user_id`) VALUES
(152, 'kb7f215d476edc94e8d22843d564a16ed', 'Concurrent Limit', 7, 'digits', '{"core":{"show_intro":"1","show_full":"1","show_feed":"0","show_compare":"1","required":"0","searchable":"0","description":"","xml_tag_name":"","field_class":"","show_lable":"3","label_break":"0","lable_class":"","icon":"","field_view_access":"1","field_view_message":"You cannot view this field","field_submit_access":"1","field_submit_message":"You cannot submit this field","field_edit_access":"1","field_edit_message":"You cannot edit this field"},"params":{"template_input":"default.php","template_output_list":"default.php","template_output_full":"default.php","sortable":"0","template_filter":"default.php","template_filter_module":"default.php","filter_enable":"0","filter_hide":"0","filter_descr":"","filter_worn":"Between %s and %s","label_min":"Min","label_max":"Max","steps":"1","decimals_num":"0","max_num":"10","separator":",","dseparator":".","val_min":"0","val_max":"1000000","prepend":"","append":"concurrent calls"},"emerald":{"subscr_skip":"3","subscr_skip_author":"1","subscr_skip_moderator":"1","field_display_subscription_msg":"You can view this field only if article author has subscription.","field_display_subscription_count":"0","field_view_subscription_msg":"Only our paid members can view this field.","field_view_subscription_count":"0","field_submit_subscription_msg":"Only our paid members can vew add this field.","field_submit_subscription_count":"0","field_edit_subscription_msg":"Only our paid members can edit this field.","field_edit_subscription_count":"0"}}', 0, '0000-00-00 00:00:00', 1, 10, 1, 0, 332, 0, 129);
