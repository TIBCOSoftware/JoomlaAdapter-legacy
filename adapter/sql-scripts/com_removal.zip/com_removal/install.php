<?php

class com_removalInstallerScript{
        private $dbPath = '/administrator/components/com_removal/db/';
        public function install() {
            $this->judgeConcurrentLimit();
            $this->updateTabels();
            $this->changeHtmlHeight();

        }
        public function update()
        {
            $this->judgeConcurrentLimit();
            $this->updateTabels();
            $this->changeHtmlHeight();
        }

        private function getAllFiles() {
            $path = JPATH_ROOT . $this->dbPath;
            $fileArr = array();
            if ( $dh = opendir($path) ) {
                $n = 0;
                while ( ($file = readdir($dh)) !== false ) {
                    if ( $file != '.' && $file != '..' ) {
                        $fileArr[$n]['fileName'] = $file;
                        $fileArr[$n]['fileType'] = substr( $file, strripos( $file, '.' )+1 );
                        $n++;
                    }
                }
                unset($fileTemp);
                closedir($dh);
            }
            return $fileArr;
        }

        private function updateTabels(){
            $needUpdate = $this->getAllFiles();
            foreach ( $needUpdate as $val ) {
                if ( $val['fileType'] == 'json' ) {
                   // $this->updateConstruct( $val['fileName'] );
                } elseif ( $val['fileType'] == 'sql' ) {
                    $this->updateData( $val['fileName'] );
                }
            }
        }

        private function updateData($file) {
            $sqlArr = $this->getFile( $file, 'Sql' );
            $db = JFactory::getDbo();
            foreach ( $sqlArr as $val ) {
                $db->setQuery($val);
                @$db->execute();
            }
        }

        private function updateConstruct( $filename ) {
            $table = substr( $filename, 0, stripos( $filename, '.') );
            $addArr = array();
            $db = JFactory::getDbo();
            $sql = "DESCRIBE `{$table}`";
            $db->setQuery($sql);
            $oldArr = $db->loadObjectList('Field');
            if ( !empty($oldArr) ) {
                    $newArr = $this->getFile($filename);
                    foreach ( $newArr as $val ) {
                        if ( array_key_exists($val->Field, $oldArr) ) {
                            if ( $val->Type != $oldArr[$val->Field]->Type || $val->Key != $oldArr[$val->Field]->Key || $val->Null != $oldArr[$val->Field]->Null || $val->Default != $oldArr[$val->Field]->Default ) {
                                $addArr['change'][$val->Field] = $val;
                                $addArr['change'][$val->Field]->OldKey = $oldArr[$val->Field]->Key;
                                if ( $val->Key == $oldArr[$val->Field]->Key ){
                                    unset($addArr['change'][$val->Field]->Key);
                                    unset($addArr['change'][$val->Field]->OldKey);
                                }
                            }
                            unset($oldArr[$val->Field]);
                        } else {
                            $addArr['add'][$val->Field]['Field'] = $val->Field;
                            $addArr['add'][$val->Field]['Type'] = $val->Type;
                            $addArr['add'][$val->Field]['Null'] = $val->Null;
                            $addArr['add'][$val->Field]['Key'] = $val->Key;
                            $addArr['add'][$val->Field]['Default'] = $val->Default;
                            $addArr['add'][$val->Field]['Extra'] = $val->Extra;
                        }
                    }
                    if ( !empty($oldArr) ) {
                        $addArr['del'] = array_keys($oldArr);
                    }
                    if( isset( $addArr ) && !empty( $addArr ) )
                    {
                        if ( !empty( $addArr['add'] ) )
                            $this->addField ($table, $addArr['add']);
                        if ( !empty( $addArr['change'] ) )
                            $this->changeField ($table, $addArr['change']);
                        if ( !empty( $addArr['del'] ) )
                            $this->delField ($table, $addArr['del']);
                    }
            }
        }

        private function addField( $table, $fieldArr ) {
            foreach ( $fieldArr as $val ) {
               $db = JFactory::getDbo();
               if ( !empty( $val['Default'] ) )
               {
                   $default = "DEFAULT '{$val['Default']}'";
               }
               if ( $val['Null'] == 'NO' )
               {
                   $null = "NOT NULL";
               }
               if ( !empty( $val['Key'] ) )
               {
                   switch ( $val['Key'] ) {
                        case 'PRI' :
                                    $key = ', ADD PRIMARY KEY(`'.$val["Field"].'`) ';
                                    break;
                        case 'MUL' :
                                    $key = ', ADD INDEX(`'.$val["Field"].'`) ';
                                    break;
                        case 'UNI' :
                                    $key = ', ADD UNIQUE(`'.$val["Field"].'`) ';
                                    break;
                   }

               }
               $sql = "ALTER TABLE `{$table}` ADD `{$val['Field']}` {$val['Type']} {$null} {$default} {$key}";
               $db->setQuery($sql);
               $db->execute();
            }
        }

        private function changeField( $table, $fieldArr ) {
            foreach ( $fieldArr as $val ) {
                if ( strtoupper($val->Null) == 'NO' )
                    $null = 'NOT NULL';
                else
                    $null = 'NULL';
                if ( $val->Default == NULL )
                    $default = '';
                else {
                    $default = "DEFAULT {$val->Default}";
                }
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` CHANGE `{$val->Field}` `{$val->Field}`{$val->Type} {$null} {$default}";
                $db->setQuery($sql);
                @$db->execute();
                if ( isset( $val->Key ) )
                    $this->changeKey($table, $val->Key, $val->Field, $val->OldKey);
            }
        }
        private function changeKey( $table, $key, $field, $oldKey ){
            if ( empty($key) ){
                $db = JFactory::getDbo();
                $sql = "drop index {$field} on {$table}";
                $db->setQuery($sql);
                @$db->execute();
            }elseif ( empty($oldKey) ) {
                switch ( $key ) {
                    case 'PRI' :
                                $keyText = 'PRIMARY KEY(`'.$field.'`) ';
                                break;
                    case 'MUL' :
                                $keyText = 'INDEX(`'.$field.'`) ';
                                break;
                    case 'UNI' :
                                $keyText = 'UNIQUE(`'.$field.'`) ';
                                break;
                }
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` ADD {$keyText}";
                $db->setQuery($sql);
                @$db->execute();
            } else {
                switch ( $key ) {
                    case 'PRI' :
                                $keyText = 'PRIMARY KEY(`'.$field.'`) ';
                                break;
                    case 'MUL' :
                                $keyText = 'INDEX(`'.$field.'`) ';
                                break;
                    case 'UNI' :
                                $keyText = 'UNIQUE(`'.$field.'`) ';
                                break;
                }
                $db = JFactory::getDbo();
                $sql = "drop index {$field} on {$table}";
                $db->setQuery($sql);
                @$db->execute();
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` ADD {$keyText}";
                $db->setQuery($sql);
                @$db->execute();
            }
        }

        private function delField( $table, $fieldArr ) {
            foreach ( $fieldArr as $val ) {
                $db = JFactory::getDbo();
                $sql = "ALTER TABLE `{$table}` DROP `{$val}`";
                $db->setQuery($sql);
                $db->execute();
            }

        }
        private function getFile( $filename,$type = 'Json' ) {
            $path = JPATH_ROOT . $this->dbPath . $filename;
            if ( $type == 'Sql' ) {
                $resArr = array();
                $fh = fopen( $path, 'r' );
                while ( !feof($fh) ) {
                   $line = trim(fgets($fh));
                    if ( !empty($line) ) {
                        $lineEnd = substr($line,-1);
                        if ( $lineEnd == ';' ) {
                            if ( empty( $temp ) ) {
                                $line = substr($line,0, -1);
                                $resArr[] = $line;
                            } else {
                                $temp .= $line;
                                $temp = substr($temp,0, -1);
                                $resArr[] = $temp;
                                $temp = '';
                            }

                        } else {
                            $temp .= $line;
                        }
                    }
                }
                $result = $resArr;
            }else if ( $type == 'Json' ) {
                $file = file_get_contents( $path );
                $result = json_decode($file);
            }
            return $result;
        }
        private function changeHtmlHeight(){
            $db = JFactory::getDbo();
            $sql = 'SELECT `extension_id`, `params` FROM `#__extensions` WHERE `name` = "plg_editors_tinymce" AND `type` = "plugin"';
            $db->setQuery($sql);
            $obj = $db->loadObject();
            if ( isset($obj->extension_id) && !empty($obj->extension_id) ) {
                $arr = json_decode($obj->params,true);
                if ( isset($arr['html_height']) ) {
                    $arr['html_height'] = "300";
                }
                $json = addslashes(json_encode($arr));
                $inSql = 'UPDATE `#__extensions` SET `params` = \''.$json.'\' WHERE `extension_id` = '.$obj->extension_id;
                $db->setQuery($inSql);
                $db->execute();
            }
            return true;
        }

        private function judgeConcurrentLimit(){
            $db = JFactory::getDbo();
            $sql = 'SELECT `label` from `#__js_res_fields` where id=152';
            $db->setQuery($sql);
            $obj = $db->loadObject();
            $sql2 = 'SELECT `title` from `#__assets` where id=332';
            $db->setQuery($sql2);
            $obj2 = $db->loadObject();
            if( isset($obj->label) && isset($obj2->title)){
                return false;
            }else{
                $sql3 = 'INSERT INTO `#__js_res_fields` (`id`, `key`, `label`, `type_id`, `field_type`, `params`, `checked_out`, `checked_out_time`, `published`, `ordering`, `access`, `group_id`, `asset_id`, `filter`, `user_id`) VALUES
                (152, \'kb7f215d476edc94e8d22843d564a16ed\', \'Concurrent Limit\', 7, \'digits\', \'{"core":{"show_intro":"1","show_full":"1","show_feed":"0","show_compare":"1","required":"0","searchable":"0","description":"","xml_tag_name":"","field_class":"","show_lable":"3","label_break":"0","lable_class":"","icon":"","field_view_access":"1","field_view_message":"You cannot view this field","field_submit_access":"1","field_submit_message":"You cannot submit this field","field_edit_access":"1","field_edit_message":"You cannot edit this field"},"params":{"template_input":"default.php","template_output_list":"default.php","template_output_full":"default.php","sortable":"0","template_filter":"default.php","template_filter_module":"default.php","filter_enable":"0","filter_hide":"0","filter_descr":"","filter_worn":"Between %s and %s","label_min":"Min","label_max":"Max","steps":"1","decimals_num":"0","max_num":"10","separator":",","dseparator":".","val_min":"0","val_max":"1000000","prepend":"","append":"concurrent calls"},"emerald":{"subscr_skip":"3","subscr_skip_author":"1","subscr_skip_moderator":"1","field_display_subscription_msg":"You can view this field only if article author has subscription.","field_display_subscription_count":"0","field_view_subscription_msg":"Only our paid members can view this field.","field_view_subscription_count":"0","field_submit_subscription_msg":"Only our paid members can vew add this field.","field_submit_subscription_count":"0","field_edit_subscription_msg":"Only our paid members can edit this field.","field_edit_subscription_count":"0"}}\', 0, \'0000-00-00 00:00:00\', 1, 10, 1, 0, 332, 0, 129)';
                $db->setQuery($sql3);
                $db->execute();
                $sql4 = 'INSERT INTO `#__assets` (`id`, `parent_id`, `lft`, `rgt`, `level`, `name`, `title`, `rules`) VALUES (332, 1, 431, 432, 1, \'com_cobalt.field.152\', \'Concurrent Limit\', \'\')';
                $db->setQuery($sql4);
                $db->execute();
            }
            return true;
        }
}

