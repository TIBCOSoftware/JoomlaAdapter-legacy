ALTER TABLE `asg_logs` CHANGE `content` `content` LONGTEXT;
ALTER TABLE `#__js_res_record` CHANGE `access` `access` INT(10);